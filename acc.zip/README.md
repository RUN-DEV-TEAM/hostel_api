# hostel_api
Backend app for hostel allocation
