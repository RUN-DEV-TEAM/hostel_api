
class Userbject:
    def __init__(self, id, email, created_at, updated_at):
        self.id = id
        self.email = email
        self.created_at = created_at
        self.updated_at = updated_at


class Userbject2:
    def __init__(self, id, email, password, created_at, updated_at):
        self.id = id
        self.email = email
        self.password = password
        self.created_at = created_at
        self.updated_at = updated_at